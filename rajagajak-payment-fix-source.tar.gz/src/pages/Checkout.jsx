import { useCallback, useEffect, useRef, useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { PencilLine, X } from "lucide-react";
import Navbar from "../components/Navbar.jsx";
import { useCart } from "../context/useCart.js";
import { useAuth } from "../context/useAuth.js";
import * as api from "../services/api.js";
import { calculateCheckoutGrandTotal } from "../utils/checkoutPricing.js";
import {
  getCurrentLocation,
  getLocationErrorMessage,
} from "../utils/location.js";
import { formatQuantity } from "../utils/quantity.js";

const money = (value) => `₹${Number(value || 0).toLocaleString("en-IN")}`;
const CHECKOUT_DRAFT_KEY = "rajagajak_checkout_draft";

const readCheckoutDraft = () => {
  try {
    return JSON.parse(sessionStorage.getItem(CHECKOUT_DRAFT_KEY) || "{}");
  } catch {
    return {};
  }
};

const deliveryAddressPayload = (address) => ({
  name: address.name,
  mobile: address.mobile,
  address: address.houseShop,
  fullAddress: address.fullAddress || "",
  building: address.building || "",
  houseNumber: address.houseNumber || "",
  road: address.road || "",
  locality: address.locality || "",
  district: address.district || "",
  area: address.area,
  city: address.city,
  state: address.state,
  pincode: address.pincode,
  country: address.country || "",
  latitude: address.latitude,
  longitude: address.longitude,
  locationDetected: Boolean(address.locationDetected),
  locationSource: address.locationDetected ? "gps" : "manual",
});

const loadRazorpayCheckoutScript = async () => {
  if (window.Razorpay) return true;
  await new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => {
      if (window.Razorpay) resolve(true);
      else reject(new Error("Razorpay checkout did not initialize."));
    };
    script.onerror = () => reject(new Error("Unable to load Razorpay checkout."));
    document.body.appendChild(script);
  });
  return Boolean(window.Razorpay);
};

export default function Checkout() {
  const { cartItems, clearCart } = useCart();
  const { user, signOut } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [address, setAddress] = useState(() => {
    const draft = readCheckoutDraft();
    const savedAddress = user?.address;
    const structuredAddress =
      savedAddress && typeof savedAddress === "object" ? savedAddress : null;
    const profileAddress = {
      name: user?.name || "",
      mobile: user?.mobile || "",
      houseShop: structuredAddress
        ? structuredAddress.addressLine1 || ""
        : savedAddress || "",
      area: structuredAddress?.addressLine2 || "",
      city: structuredAddress?.city || "",
      state: structuredAddress?.state || "",
      pincode: structuredAddress?.pincode || user?.pinCode || "",
      country: structuredAddress?.country || "",
      fullAddress: structuredAddress
        ? [
            structuredAddress.addressLine1,
            structuredAddress.addressLine2,
            structuredAddress.city,
            [structuredAddress.state, structuredAddress.pincode || user?.pinCode]
              .filter(Boolean)
              .join(" - "),
            structuredAddress.country,
          ]
            .filter(Boolean)
            .join(", ")
        : "",
    };
    return draft.address
      ? {
          ...profileAddress,
          ...draft.address,
          name: draft.address.name || profileAddress.name,
          mobile: draft.address.mobile || profileAddress.mobile,
        }
      : profileAddress;
  });
  const [deliveryMode, setDeliveryMode] = useState(
    () => readCheckoutDraft().deliveryMode || "",
  );
  const [manualAddressOpen, setManualAddressOpen] = useState(false);
  const [customerLocation, setCustomerLocation] = useState(
    () => readCheckoutDraft().customerLocation || null,
  );
  const [deliveryQuoteState, setDeliveryQuoteState] = useState(null);
  const [deliveryError, setDeliveryError] = useState("");
  const [deliveryCalculating, setDeliveryCalculating] = useState(() => {
    const draft = readCheckoutDraft();
    return draft.deliveryMode === "gps" && Boolean(draft.customerLocation);
  });
  const [gettingLocation, setGettingLocation] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const paymentSubmissionLock = useRef(false);
  const [coupons, setCoupons] = useState([]);
  const [couponError, setCouponError] = useState("");
  const [selectedCouponCode, setSelectedCouponCode] = useState("");
  const [couponInput, setCouponInput] = useState("");
  const [applyingCoupon, setApplyingCoupon] = useState(false);
  const [appliedCouponResult, setAppliedCouponResult] = useState(null);
  const [couponWindowOpen, setCouponWindowOpen] = useState(false);
  const cartKey = cartItems
    .map((item) => `${item.productId}:${item.quantityKg}`)
    .join("|");
  const deliveryQuote =
    deliveryQuoteState?.cartKey === cartKey ? deliveryQuoteState.data : null;
  const deliveryQuotePending =
    deliveryCalculating ||
    Boolean(
      deliveryQuoteState &&
        deliveryQuoteState.cartKey !== cartKey &&
        deliveryMode &&
        !manualAddressOpen,
    );
  const setDeliveryQuote = useCallback(
    (value) =>
      setDeliveryQuoteState(value ? { cartKey, data: value } : null),
    [cartKey],
  );
  const [quoteResult, setQuoteResult] = useState(null);
  const [quoteFailure, setQuoteFailure] = useState(null);
  const quote = quoteResult?.key === cartKey ? quoteResult.data : null;
  const quoteError = quoteFailure?.key === cartKey ? quoteFailure.message : "";
  const appliedCoupon =
    appliedCouponResult?.key === cartKey ? appliedCouponResult.data : null;

  const redirectToLoginOnUnauthorized = (requestError) => {
    if (requestError.status !== 401) return false;

    signOut();
    navigate("/login", {
      replace: true,
      state: { from: location },
    });
    return true;
  };

  useEffect(() => {
    sessionStorage.setItem(
      CHECKOUT_DRAFT_KEY,
      JSON.stringify({ address, deliveryMode, customerLocation }),
    );
  }, [address, deliveryMode, customerLocation]);

  useEffect(() => {
    let active = true;
    api
      .activeCoupons()
      .then((response) => {
        if (active) setCoupons(response.data || []);
      })
      .catch(() => {
        if (active) setCoupons([]);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;
    if (!cartItems.length) return undefined;
    api
      .quoteOrder(
        cartItems.map((item) => ({
          productId: item.productId,
          quantityKg: item.quantityKg,
        })),
      )
      .then((response) => {
        if (active) setQuoteResult({ key: cartKey, data: response.data });
      })
      .catch((requestError) => {
        if (active) {
          setQuoteFailure({
            key: cartKey,
            message: requestError.message || "Unable to price your order.",
          });
        }
      });
    return () => {
      active = false;
    };
  }, [cartItems, cartKey]);

  useEffect(() => {
    if (deliveryMode !== "gps" || !customerLocation) return undefined;

    let active = true;
    api
      .quoteShipping({
        customerLocation: {
          latitude: customerLocation.latitude,
          longitude: customerLocation.longitude,
        },
        items: cartItems.map(({ productId, quantityKg }) => ({
          productId,
          quantityKg,
        })),
      })
      .then((response) => {
        if (!active) return;
        const shipping = response.data.shipping;
        const location = shipping.location || {};
        if (!shipping.fullAddress || !location.city || !location.state)
          throw new Error(
            "We couldn't get a readable address for your current location.",
          );
        setAddress((current) => ({
          ...current,
          houseShop: [location.building, location.houseNumber, location.road]
            .filter(Boolean)
            .join(", "),
          fullAddress: shipping.fullAddress,
          building: location.building || "",
          houseNumber: location.houseNumber || "",
          road: location.road || "",
          locality: location.locality || "",
          district: location.district || "",
          area: [location.locality, location.area, location.district]
            .filter(Boolean)
            .join(", "),
          city: location.city,
          state: location.state,
          pincode: location.pincode || "",
          country: location.country || "",
          latitude: customerLocation.latitude,
          longitude: customerLocation.longitude,
          locationDetected: true,
        }));
        setDeliveryQuote(shipping);
      })
      .catch((requestError) => {
        if (active) {
          setDeliveryQuote(null);
          setDeliveryMode("");
          setDeliveryError(
            requestError.message ||
              "We couldn't get a readable address for your current location. Please enter your delivery address manually.",
          );
        }
      })
      .finally(() => {
        if (active) {
          setDeliveryCalculating(false);
          setGettingLocation(false);
        }
      });

    return () => {
      active = false;
    };
  }, [deliveryMode, customerLocation, cartItems, cartKey, setDeliveryQuote]);

  useEffect(() => {
    if (
      !cartItems.length ||
      deliveryMode !== "address" ||
      !address.houseShop.trim() ||
      !address.city.trim() ||
      !address.state.trim() ||
      !/^\d{6}$/.test(address.pincode.trim())
    )
      return undefined;

    let active = true;
    const timer = window.setTimeout(() => {
      setDeliveryCalculating(true);
      setDeliveryQuote(null);
      setDeliveryError("");
      api
        .quoteShipping({
          shippingAddress: deliveryAddressPayload(address),
          items: cartItems.map(({ productId, quantityKg }) => ({
            productId,
            quantityKg,
          })),
        })
        .then((response) => {
          if (active) setDeliveryQuote(response.data.shipping);
        })
        .catch((requestError) => {
          if (active) {
            setDeliveryQuote(null);
            setDeliveryError(
              requestError.message ||
                "Unable to recalculate delivery for the updated address.",
            );
          }
        })
        .finally(() => {
          if (active) setDeliveryCalculating(false);
        });
    }, 500);

    return () => {
      active = false;
      window.clearTimeout(timer);
    };
  }, [
    cartItems,
    cartKey,
    deliveryMode,
    address,
    address.houseShop,
    address.area,
    address.city,
    address.state,
    address.pincode,
    setDeliveryQuote,
  ]);

  const updateAddress = (field, value) => {
    removeCoupon();
    setAddress((current) => ({
      ...current,
      [field]: value,
      fullAddress: "",
      building: "",
      latitude: undefined,
      longitude: undefined,
      locationDetected: false,
    }));
    setDeliveryMode("address");
    setCustomerLocation(null);
    setDeliveryQuote(null);
    setDeliveryError("");
    setDeliveryCalculating(false);
  };

  const toggleManualAddress = () => {
    if (manualAddressOpen) {
      setManualAddressOpen(false);
      return;
    }
    setDeliveryQuote(null);
    setDeliveryError("");
    setDeliveryMode("address");
    setCustomerLocation(null);
    setAddress((current) => ({
      ...current,
      fullAddress: "",
      building: "",
      latitude: undefined,
      longitude: undefined,
      locationDetected: false,
    }));
    setDeliveryCalculating(false);
    removeCoupon();
    setManualAddressOpen(true);
  };

  const editManualAddress = () => {
    removeCoupon();
    setDeliveryQuote(null);
    setDeliveryError("");
    setDeliveryMode("address");
    setCustomerLocation(null);
    setAddress((current) => ({
      ...current,
      fullAddress: "",
      locationDetected: false,
    }));
    setManualAddressOpen(true);
  };

  const calculateManualDelivery = () => {
    setDeliveryError("");
    if (
      !address.name.trim() ||
      !address.houseShop.trim() ||
      !address.area.trim() ||
      !address.city.trim() ||
      !address.state.trim()
    ) {
      setDeliveryError("Please enter a valid delivery address.");
      return;
    }
    if (!/^[6-9]\d{9}$/.test(address.mobile.trim())) {
      setDeliveryError("Please enter a valid 10-digit mobile number.");
      return;
    }
    if (!/^\d{6}$/.test(address.pincode.trim())) {
      setDeliveryError("Please enter a valid 6-digit pincode.");
      return;
    }
    if (!deliveryQuote) setDeliveryCalculating(true);
    setManualAddressOpen(false);
  };

  const useDeviceLocation = async () => {
    removeCoupon();
    setGettingLocation(true);
    setManualAddressOpen(false);
    setDeliveryMode("");
    setCustomerLocation(null);
    setDeliveryQuote(null);
    setDeliveryError("");
    setDeliveryCalculating(true);
    try {
      const location = await getCurrentLocation();
      setCustomerLocation(location);
      setDeliveryMode("gps");
    } catch (locationError) {
      setDeliveryMode("");
      setManualAddressOpen(true);
      setGettingLocation(false);
      setDeliveryCalculating(false);
      setDeliveryError(getLocationErrorMessage(locationError));
    }
  };

  const applyCouponCode = async (requestedCode = couponInput) => {
    const code = String(requestedCode || "")
      .trim()
      .toUpperCase();
    if (!code) return setCouponError("Enter a coupon code.");
    if (!quote || !deliveryQuote)
      return setCouponError(
        "Calculate delivery charges before applying a coupon.",
      );
    setApplyingCoupon(true);
    setCouponError("");
    try {
      const response = await api.applyCoupon(code, {
        cartItems: cartItems.map(({ productId, quantityKg }) => ({
          productId,
          quantityKg,
        })),
        deliveryAddress: deliveryAddressPayload(address),
        ...(deliveryMode === "gps" ? { customerLocation } : {}),
        paymentMethod: "razorpay",
      });
      setAppliedCouponResult({ key: cartKey, data: response.data });
      setSelectedCouponCode(response.data.coupon.code);
      setCouponInput(response.data.coupon.code);
      setCouponWindowOpen(false);
    } catch (requestError) {
      setAppliedCouponResult(null);
      setSelectedCouponCode("");
      if (!redirectToLoginOnUnauthorized(requestError)) {
        setCouponError(requestError.message || "Unable to apply coupon.");
      }
    } finally {
      setApplyingCoupon(false);
    }
  };

  const removeCoupon = () => {
    setSelectedCouponCode("");
    setCouponInput("");
    setAppliedCouponResult(null);
    setCouponError("");
  };

  const subtotal = Number(quote?.pricing?.subtotal || 0);
  const couponDiscount = appliedCoupon
    ? Math.min(Math.max(0, Number(appliedCoupon.discount || 0)), subtotal)
    : 0;
  const baseTaxableAmount = Number(quote?.pricing?.taxableAmount || 0);
  const shippingCharges = Number(
    appliedCoupon?.finalShipping ?? deliveryQuote?.shippingCharge ?? 0,
  );
  const shippingDiscount = Number(appliedCoupon?.shippingDiscount || 0);
  const discountedTaxableAmount = Number(
    appliedCoupon?.pricing?.taxableAmount ??
      Math.max(0, baseTaxableAmount - couponDiscount),
  );
  const currentGrandTotal = calculateCheckoutGrandTotal({
    taxableAmount: baseTaxableAmount,
    couponDiscount,
    gstAmount: appliedCoupon?.pricing?.totalGST ?? quote?.pricing?.totalGST,
    shippingCharge: shippingCharges,
  });

  const submit = async (event) => {
    event.preventDefault();
    if (paymentSubmissionLock.current) return;
    setError("");
    if (!cartItems.length) return setError("Your bag is empty.");
    if (!user) {
      navigate("/login", {
        state: { from: { pathname: "/checkout" } },
      });
      return;
    }
    const gpsAddressReady =
      deliveryMode === "gps" &&
      address.locationDetected &&
      Boolean(address.fullAddress) &&
      Boolean(customerLocation);
    if (
      !address.name.trim() ||
      !/^[6-9]\d{9}$/.test(address.mobile.trim()) ||
      (!gpsAddressReady &&
        (!address.houseShop.trim() ||
          !address.area.trim() ||
          !address.city.trim() ||
          !address.state.trim()))
    )
      return setError("Please enter a valid delivery address.");
    if (!gpsAddressReady && !/^\d{6}$/.test(address.pincode.trim()))
      return setError("Please enter a valid 6-digit pincode.");
    if (deliveryMode === "address") {
      if (!deliveryQuote)
        return setError(
          "Couldn't find this address. Please check your address and try again.",
        );
    }
    if (!deliveryQuote)
      return setError(
        "We couldn't calculate delivery charges. Please try again or enter your delivery address.",
      );

    const orderPayload = {
      clientRequestId: crypto.randomUUID(),
      paymentMethod: "razorpay",
      shippingAddress: deliveryAddressPayload(address),
      ...(deliveryMode === "gps" ? { customerLocation } : {}),
      items: cartItems.map((item) => ({
        productId: item.productId,
        quantityKg: item.quantityKg,
      })),
      couponCode: appliedCoupon?.coupon?.code || undefined,
    };

    paymentSubmissionLock.current = true;
    setSubmitting(true);
    try {
      const configResponse = await api.paymentConfig();
      const razorpayKeyId = configResponse.keyId;
      if (!razorpayKeyId) {
        throw new Error(
          "Razorpay payment is temporarily unavailable. Please contact support or try again later.",
        );
      }
      await loadRazorpayCheckoutScript();
      const response = await api.createRazorpayOrder(orderPayload);
      const razorpayOrder = response.data?.razorpayOrder;
      if (!razorpayOrder?.id) {
        throw new Error("Unable to create the Razorpay order.");
      }

      const razorpay = new window.Razorpay({
        key: razorpayKeyId,
        amount: razorpayOrder.amount,
        currency: razorpayOrder.currency,
        order_id: razorpayOrder.id,
        name: "Rajagajak",
        description: "Order payment",
        image: "",
        handler: async (paymentResponse) => {
          try {
            const verification = await api.verifyRazorpayPayment({
              ...orderPayload,
              razorpay_order_id: paymentResponse.razorpay_order_id,
              razorpay_payment_id: paymentResponse.razorpay_payment_id,
              razorpay_signature: paymentResponse.razorpay_signature,
            });
            sessionStorage.removeItem(CHECKOUT_DRAFT_KEY);
            clearCart();
            navigate(`/order-success/${verification.data._id}`, {
              state: { order: verification.data },
            });
          } catch (verificationError) {
            if (!redirectToLoginOnUnauthorized(verificationError)) {
              setError(
                verificationError.message ||
                  "Payment verification failed. Please contact support.",
              );
            }
          } finally {
            paymentSubmissionLock.current = false;
            setSubmitting(false);
          }
        },
        prefill: {
          name: user?.name || "",
          email: user?.email || "",
          contact: user?.mobile || "",
        },
        theme: {
          color: "#d97706",
        },
        modal: {
          ondismiss: () => {
            paymentSubmissionLock.current = false;
            setSubmitting(false);
            setError("Payment was cancelled. Your order was not placed.");
          },
        },
      });

      razorpay.on("payment.failed", () => {
        paymentSubmissionLock.current = false;
        setSubmitting(false);
        setError("Payment failed. Please try again or contact support.");
      });
      razorpay.open();
    } catch (requestError) {
      if (!redirectToLoginOnUnauthorized(requestError)) {
        setError(requestError.message || "Unable to place your order.");
      }
      paymentSubmissionLock.current = false;
      setSubmitting(false);
    }
  };

  if (!cartItems.length && !submitting)
    return (
      <div className="app-shell">
        <Navbar />
        <main className="dashboard">
          <div className="alert">
            Your bag is empty. <Link to="/dashboard">Browse products</Link>
          </div>
        </main>
      </div>
    );
  return (
    <div className="app-shell">
      <Navbar />
      <main className="dashboard checkout-page">
        <Link className="back-link" to="/bag">
          Back to bag
        </Link>
        <div className="page-heading">
          <div>
            <span className="eyebrow">Secure order</span>
            <h1>Checkout.</h1>
            <p>Confirm your delivery details and price breakdown.</p>
          </div>
        </div>
        {error && <div className="alert">{error}</div>}
        {quoteError && <div className="alert">{quoteError}</div>}
        <form className="checkout-layout" onSubmit={submit}>
          <section className="checkout-card">
            <h2>Delivery Location</h2>
            <div className="delivery-location-actions">
              <button
                className="outline-action"
                type="button"
                disabled={gettingLocation || deliveryQuotePending}
                onClick={useDeviceLocation}
              >
                {gettingLocation
                  ? "Detecting your location..."
                  : "📍 Use My Current Location"}
              </button>
              <span>OR</span>
              <button
                className="outline-action"
                type="button"
                disabled={gettingLocation || deliveryQuotePending}
                aria-expanded={manualAddressOpen}
                onClick={
                  deliveryMode === "gps" && address.locationDetected
                    ? editManualAddress
                    : toggleManualAddress
                }
              >
                {manualAddressOpen
                  ? "Cancel address entry"
                  : deliveryMode === "gps" && address.locationDetected
                    ? "Change Address"
                    : "Enter a delivery address"}
              </button>
            </div>
            {deliveryQuotePending && (
              <p className="delivery-location-status">
                Calculating delivery charges...
              </p>
            )}
            {deliveryError && (
              <div className="alert alert-inline">{deliveryError}</div>
            )}
            {deliveryQuote && (
              <div className="delivery-quote">
                {((deliveryMode === "address" && !manualAddressOpen) ||
                  (deliveryMode === "gps" && address.locationDetected)) && (
                  <div className="delivery-quote-address">
                    <div>
                      <strong>
                        {deliveryMode === "gps"
                          ? "✓ Delivery location detected"
                          : "Delivery address confirmed"}
                      </strong>
                      <motion.button
                        className="edit-address-action"
                        type="button"
                        whileHover={{ y: -2, scale: 1.02 }}
                        whileTap={{ scale: 0.97 }}
                        onClick={editManualAddress}
                      >
                        <PencilLine size={15} aria-hidden="true" />
                        <span>Change Address</span>
                      </motion.button>
                    </div>
                    {address.name && <span>{address.name}</span>}
                    {address.mobile && <span>{address.mobile}</span>}
                    <span>
                      {address.fullAddress ||
                        `${address.houseShop}, ${address.area}, ${address.city}, ${address.state} - ${address.pincode}`}
                    </span>
                  </div>
                )}
                {deliveryQuote.deliveryCategory === "outside-bhopal" ? (
                  <>
                    <div>
                      <span>Delivery location</span>
                      <strong>
                        {[
                          deliveryQuote.location?.city ||
                            deliveryQuote.location?.district,
                          deliveryQuote.location?.state,
                          deliveryQuote.location?.pincode,
                        ]
                          .filter(Boolean)
                          .join(", ")}
                      </strong>
                    </div>
                    <div>
                      <span>Product weight</span>
                      <strong>
                        {Number(deliveryQuote.productWeightKg).toFixed(3)} kg
                      </strong>
                    </div>
                    <div className="delivery-rate-breakdown">
                      <strong>Applicable delivery rates</strong>
                      {deliveryQuote.rateBreakdown?.map((slab) => (
                        <div key={slab.label}>
                          <span>
                            {slab.label} · {slab.weightKg} kg ×{" "}
                            {money(slab.ratePerKg)}/kg
                          </span>
                          <strong>{money(slab.charge)}</strong>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <div>
                    <span>
                      {deliveryQuote.estimated
                        ? "Estimated shipping zone"
                        : "Delivery Distance"}
                    </span>
                    <strong>
                      {deliveryQuote.estimated
                        ? deliveryQuote.shippingZone
                            ?.replace("-", " ")
                            .replace(/\b\w/g, (letter) => letter.toUpperCase())
                        : `${Number(deliveryQuote.distanceKm).toFixed(1)} KM`}
                    </strong>
                  </div>
                )}
                <div>
                  <span>
                    {deliveryQuote.deliveryCategory === "outside-bhopal"
                      ? "Total delivery charge"
                      : deliveryQuote.estimated
                      ? "Estimated shipping charges"
                      : "Shipping Charges"}
                  </span>
                  <strong>{money(deliveryQuote.shippingCharge)}</strong>
                </div>
                {deliveryQuote.estimated &&
                  deliveryQuote.deliveryCategory !== "outside-bhopal" && (
                  <>
                    <div>
                      <span>Parcel weight (incl. packaging)</span>
                      <strong>
                        {Number(deliveryQuote.shipmentWeightKg).toFixed(2)} KG
                      </strong>
                    </div>
                    <small>
                      This is an estimated shipping charge, not a live courier
                      quote. Final service availability and carrier charges may
                      vary.
                    </small>
                  </>
                )}
                {deliveryQuote.distanceMethod === "haversine" && (
                  <small>
                    Road routing is unavailable; showing an approximate direct
                    distance.
                  </small>
                )}
                {!deliveryQuote.estimated &&
                  deliveryQuote.geocodingPrecision === "postcode" && (
                  <small>
                    Exact street match was unavailable; distance is estimated
                    from this postcode area.
                  </small>
                  )}
              </div>
            )}
            <AnimatePresence initial={false}>
              {manualAddressOpen && (
                <motion.div
                  className="manual-address-panel"
                  initial={{ height: 0, opacity: 0, y: -8 }}
                  animate={{ height: "auto", opacity: 1, y: 0 }}
                  exit={{ height: 0, opacity: 0, y: -8 }}
                  transition={{ duration: 0.28, ease: "easeInOut" }}
                  style={{ overflow: "hidden" }}
                >
                  <h2>Delivery address</h2>
                  <fieldset
                    className="checkout-fields"
                    disabled={deliveryQuotePending}
                  >
                    <input
                      required
                      placeholder="Full name"
                      value={address.name}
                      onChange={(event) =>
                        updateAddress("name", event.target.value)
                      }
                    />
                    <input
                      required
                      inputMode="numeric"
                      pattern="[6-9][0-9]{9}"
                      placeholder="Mobile number"
                      value={address.mobile}
                      onChange={(event) =>
                        updateAddress("mobile", event.target.value)
                      }
                    />
                    <input
                      required
                      placeholder="House/Shop No."
                      value={address.houseShop}
                      onChange={(event) =>
                        updateAddress("houseShop", event.target.value)
                      }
                    />
                    <input
                      required
                      placeholder="Area"
                      value={address.area}
                      onChange={(event) =>
                        updateAddress("area", event.target.value)
                      }
                    />
                    <input
                      required
                      placeholder="City"
                      value={address.city}
                      onChange={(event) =>
                        updateAddress("city", event.target.value)
                      }
                    />
                    <input
                      required
                      placeholder="State"
                      value={address.state}
                      onChange={(event) =>
                        updateAddress("state", event.target.value)
                      }
                    />
                    <input
                      required
                      inputMode="numeric"
                      maxLength={6}
                      placeholder="Pincode"
                      value={address.pincode}
                      onChange={(event) =>
                        updateAddress("pincode", event.target.value)
                      }
                    />
                    {deliveryMode === "address" &&
                      address.pincode &&
                      !/^\d{6}$/.test(address.pincode.trim()) && (
                        <span className="delivery-location-status">
                          Please enter a valid 6-digit pincode.
                        </span>
                      )}
                  </fieldset>
                  <button
                    className="primary-action calculate-delivery-action"
                    type="button"
                    disabled={deliveryQuotePending || gettingLocation}
                    onClick={calculateManualDelivery}
                  >
                    {deliveryQuotePending
                      ? "Calculating delivery charges..."
                      : "Confirm address"}
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
            <h2>Order items</h2>
            <div className="checkout-items">
              {(quote?.items || cartItems).map((item) => (
                <div
                  className="checkout-item"
                  key={item.itemKey || item.productId}
                >
                  <div className="bag-item-image">
                    {item.image && (
                      <img
                        src={item.image}
                        alt={item.productName || item.title}
                      />
                    )}
                  </div>
                  <div>
                    <strong>{item.productName || item.title}</strong>
                    <span>
                      Price: {money(item.pricePerKg || item.unitPrice || 0)}/kg
                    </span>
                    <span>
                      Quantity {formatQuantity(item.quantityKg)} · GST{" "}
                      {item.gstPercentage || 0}% · {money(item.gstAmount || 0)}
                    </span>
                  </div>
                  <strong>
                    {money(
                      item.itemTotal ||
                        (item.pricePerKg || item.price) * item.quantityKg,
                    )}
                  </strong>
                </div>
              ))}
            </div>
          </section>
          <aside className="checkout-card checkout-summary">
            <h2>Price details</h2>
            {!quote && !quoteError && (
              <p>Refreshing prices from the catalogue...</p>
            )}

            <div className="coupon-box">
              <div className="coupon-box-header">
                <span>Coupons</span>
                {appliedCoupon && (
                  <button
                    type="button"
                    className="coupon-remove-action"
                    aria-label={`Remove ${appliedCoupon.coupon.code} coupon`}
                    onClick={removeCoupon}
                  >
                    <X size={14} aria-hidden="true" />
                    <span>Remove</span>
                  </button>
                )}
              </div>
              <button
                type="button"
                className="apply-coupon-trigger"
                onClick={() => setCouponWindowOpen(true)}
              >
                <span>
                  <strong>
                    {appliedCoupon ? "Coupon applied" : "Apply coupon"}
                  </strong>
                  <small>
                    {appliedCoupon
                      ? `${appliedCoupon.coupon.code} applied · saved ${money(couponDiscount + shippingDiscount)}`
                      : "Choose from available offers"}
                  </small>
                </span>
                <span aria-hidden="true">›</span>
              </button>
              {appliedCoupon && (
                <div className="selected-coupon-pill">
                  ✓ {appliedCoupon.coupon.code} applied · You saved{" "}
                  {money(couponDiscount + shippingDiscount)}
                </div>
              )}
              {couponError && (
                <div className="alert alert-inline">{couponError}</div>
              )}
            </div>

            {couponWindowOpen && (
              <div className="coupon-window-backdrop" role="presentation">
                <section
                  className="coupon-window"
                  role="dialog"
                  aria-modal="true"
                  aria-labelledby="coupon-window-title"
                >
                  <div className="coupon-window-header">
                    <div>
                      <span className="eyebrow">Offers for you</span>
                      <h2 id="coupon-window-title">Apply coupon</h2>
                    </div>
                    <button
                      type="button"
                      className="coupon-window-close"
                      aria-label="Close coupons"
                      onClick={() => setCouponWindowOpen(false)}
                    >
                      ×
                    </button>
                  </div>
                  <div className="coupon-code-entry">
                    <input
                      aria-label="Enter coupon code"
                      placeholder="Enter coupon code"
                      value={couponInput}
                      onChange={(event) => {
                        setCouponInput(event.target.value.toUpperCase());
                        setCouponError("");
                      }}
                    />
                    <button
                      className="primary-action"
                      type="button"
                      disabled={applyingCoupon || !deliveryQuote || !quote}
                      onClick={() => applyCouponCode()}
                    >
                      {applyingCoupon ? "Applying..." : "Apply"}
                    </button>
                  </div>
                  {!deliveryQuote && (
                    <p className="muted-copy">
                      Calculate delivery before applying a coupon.
                    </p>
                  )}
                  {coupons.length === 0 ? (
                    <p className="muted-copy">
                      No coupons available right now.
                    </p>
                  ) : (
                    <div className="coupon-option-list">
                      {coupons.map((coupon) => {
                        const isSelected = selectedCouponCode === coupon.code;
                        return (
                          <button
                            key={coupon._id}
                            type="button"
                            className={`coupon-option ${isSelected ? "selected" : ""}`}
                            onClick={() => {
                              setCouponError("");
                              setCouponInput(coupon.code);
                            }}
                          >
                            <span className="coupon-code">{coupon.code}</span>
                            <span className="coupon-title">{coupon.title}</span>
                            <span className="coupon-meta">
                              {(coupon.type || coupon.discountType) ===
                              "percentage"
                                ? `${coupon.discountValue}% OFF`
                                : (coupon.type || coupon.discountType) ===
                                    "fixed"
                                  ? `${money(coupon.discountValue)} OFF`
                                  : (coupon.type || coupon.discountType) ===
                                      "free_shipping"
                                    ? "FREE SHIPPING"
                                    : (coupon.type || coupon.discountType) ===
                                        "fixed_shipping"
                                      ? `SHIPPING ${money(coupon.discountValue)}`
                                      : `${coupon.title}`}{" "}
                              · Min {money(coupon.minimumOrderValue || 0)} ·
                              Ends{" "}
                              {new Date(coupon.expiryDate).toLocaleDateString()}
                            </span>
                            {(coupon.applicableCategories?.length > 0 ||
                              coupon.applicableProducts?.length > 0) && (
                              <span className="coupon-meta">
                                Applies to:{" "}
                                {[
                                  ...(coupon.applicableCategories || []),
                                  ...(coupon.applicableProducts || []).map(
                                    (product) => product.title,
                                  ),
                                ].join(", ")}
                              </span>
                            )}
                            {coupon.eligibilityNotice && (
                              <span className="coupon-meta">
                                {coupon.eligibilityNotice}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  )}
                  {couponError && (
                    <div className="alert alert-inline">{couponError}</div>
                  )}
                </section>
              </div>
            )}

            <div>
              <span>Subtotal</span>
              <strong>{money(subtotal)}</strong>
            </div>
            <div>
              <span>Discount</span>
              <strong>-{money(quote?.pricing.discount || 0)}</strong>
            </div>
            {appliedCoupon && couponDiscount > 0 && (
              <div className="coupon-discount-row">
                <span>Coupon discount ({appliedCoupon.coupon.code})</span>
                <strong>-{money(couponDiscount)}</strong>
              </div>
            )}
            <div>
              <span>Taxable amount</span>
              <strong>{money(discountedTaxableAmount)}</strong>
            </div>
            <div>
              <span>GST</span>
              <strong>
                {money(
                  appliedCoupon?.pricing?.totalGST ?? quote?.pricing.totalGST,
                )}
              </strong>
            </div>
            <div>
              <span>Shipping</span>
              <strong>{money(shippingCharges)}</strong>
            </div>
            {shippingDiscount > 0 && (
              <div className="coupon-discount-row">
                <span>Shipping discount</span>
                <strong>-{money(shippingDiscount)}</strong>
              </div>
            )}
            <hr />
            <div className="grand-total">
              <span>Grand total</span>
              <strong>{money(currentGrandTotal)}</strong>
            </div>

            <div className="checkout-payment-methods" style={{ margin: "16px 0" }}>
              <h3 style={{ marginBottom: 12 }}>Payment Method</h3>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "10px 12px",
                  border: "1px solid #e5d9c4",
                  borderRadius: 10,
                  background: "#fff7ef",
                }}
              >
                <span>
                  <strong>Razorpay</strong>
                  <div style={{ fontSize: 12, color: "#6b7280" }}>
                    Pay securely using UPI, cards, and net banking.
                  </div>
                </span>
              </div>
            </div>

            <button
              className="primary-action"
              type="submit"
              disabled={
                submitting ||
                !quote ||
                !deliveryQuote ||
                deliveryQuotePending ||
                gettingLocation
              }
            >
              {submitting
                ? "Processing payment..."
                : `Pay ${money(currentGrandTotal)}`}
            </button>
          </aside>
        </form>
      </main>
    </div>
  );
}
